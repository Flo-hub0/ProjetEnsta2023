#include <SFML/Window/Keyboard.hpp>
#include <ios>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <tuple>
#include <chrono>
#include <mpi.h>
#include "cartesian_grid_of_speed.hpp"
#include "vortex.hpp"
#include "cloud_of_points.hpp"
#include "runge_kutta.hpp"
#include "screen.hpp"

// La taille maximale du buffer contenant les parametres qui est envoye aux processus de calcul
// A priori = 12 + 9 * 3 = 40 dans le cas du tore a 9 tourbillons
#define MAX_BUFFER_SIZE 1000

// Le buffer qui va servir a transmettre les donnees aux processus de calcul
static char *MPI_buffer;
static int MPI_position;

auto readConfigFile( std::ifstream& input )
{
    using point=Simulation::Vortices::point;

    int isMobile;
    int nbVortices;
    Numeric::CartesianGridOfSpeed cartesianGrid;
    Geometry::CloudOfPoints cloudOfPoints;
    constexpr std::size_t maxBuffer = 8192;
    char buffer[maxBuffer];
    std::string sbuffer;
    std::stringstream ibuffer;
    // Lit la première ligne de commentaire :
    input.getline(buffer, maxBuffer); // Relit un commentaire
    input.getline(buffer, maxBuffer);// Lecture de la grille cartésienne
    sbuffer = std::string(buffer,maxBuffer);
    ibuffer = std::stringstream(sbuffer);
    double xleft, ybot, h;
    int nx, ny;
    ibuffer >> xleft >> ybot >> nx >> ny >> h;

    assert((MPI_buffer = (char *)malloc(MAX_BUFFER_SIZE*sizeof(double))) != NULL);
    MPI_position = 0;
    MPI_Pack(&xleft, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    MPI_Pack(&ybot, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    MPI_Pack(&nx, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    MPI_Pack(&ny, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    MPI_Pack(&h, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    std::cout << "position = " << MPI_position << " " << std::endl;
    cartesianGrid = Numeric::CartesianGridOfSpeed({nx,ny}, point{xleft,ybot}, h);
    input.getline(buffer, maxBuffer); // Relit un commentaire
    input.getline(buffer, maxBuffer); // Lit mode de génération des particules
    sbuffer = std::string(buffer,maxBuffer);
    ibuffer = std::stringstream(sbuffer);
    int modeGeneration;
    ibuffer >> modeGeneration;
            std::cout << "modeGeneration= " << modeGeneration << std::endl;

    MPI_Pack(&modeGeneration, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    std::cout << "position = " << MPI_position << " " << std::endl;

    if (modeGeneration == 0) // Génération sur toute la grille 
    {
        int nbPoints;
        ibuffer >> nbPoints;
            std::cout << "nbPoints= " << nbPoints << std::endl;

	MPI_Pack(&nbPoints, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
    std::cout << "position = " << MPI_position << " " << std::endl;

        cloudOfPoints = Geometry::generatePointsIn(nbPoints, {cartesianGrid.getLeftBottomVertex(), cartesianGrid.getRightTopVertex()});
    }
    else 
    {
        int nbPoints;
        double xl, xr, yb, yt;
        ibuffer >> xl >> yb >> xr >> yt >> nbPoints;
    
	MPI_Pack(&xl, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
	MPI_Pack(&xr, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
	MPI_Pack(&yb, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
	MPI_Pack(&yt, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
	MPI_Pack(&nbPoints, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);

        cloudOfPoints = Geometry::generatePointsIn(nbPoints, {point{xl,yb}, point{xr,yt}});
    }
    // Lit le nombre de vortex :
    input.getline(buffer, maxBuffer); // Relit un commentaire
    input.getline(buffer, maxBuffer); // Lit le nombre de vortex
    sbuffer = std::string(buffer, maxBuffer);
    ibuffer = std::stringstream(sbuffer);
    try {
        ibuffer >> nbVortices;        
    } catch(std::ios_base::failure& err)
    {
        std::cout << "Error " << err.what() << " found" << std::endl;
        std::cout << "Read line : " << sbuffer << std::endl;
        throw err;
    }

    MPI_Pack(&nbVortices, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);

    Simulation::Vortices vortices(nbVortices, {cartesianGrid.getLeftBottomVertex(),
                                               cartesianGrid.getRightTopVertex()});
    input.getline(buffer, maxBuffer);// Relit un commentaire
    for (std::size_t iVortex=0; iVortex<nbVortices; ++iVortex)
    {
        input.getline(buffer, maxBuffer);
        double x,y,force;
        std::string sbuffer(buffer, maxBuffer);
        std::stringstream ibuffer(sbuffer);
        ibuffer >> x >> y >> force;

	MPI_Pack(&x, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
	MPI_Pack(&y, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);
	MPI_Pack(&force, 1, MPI_DOUBLE, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);

        vortices.setVortex(iVortex, point{x,y}, force);
    }
    input.getline(buffer, maxBuffer);// Relit un commentaire
    input.getline(buffer, maxBuffer);// Lit le mode de déplacement des vortex
    sbuffer = std::string(buffer,maxBuffer);
    ibuffer = std::stringstream(sbuffer);
    ibuffer >> isMobile;

    MPI_Pack(&isMobile, 1, MPI_INT, MPI_buffer, MAX_BUFFER_SIZE, &MPI_position, MPI_COMM_WORLD);

    return std::make_tuple(vortices, isMobile, cartesianGrid, cloudOfPoints);
}

auto initComputing(int buf_size)
{
    using point=Simulation::Vortices::point;

    int isMobile, modeGeneration;
    int nbVortices, nbPoints, nx, ny;
    Numeric::CartesianGridOfSpeed cartesianGrid;
    Geometry::CloudOfPoints cloudOfPoints;
    double xleft, ybot, h, xl, xr, yb, yt, x,y, force;

    MPI_position = 0;
    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &xleft, 1, MPI_DOUBLE, MPI_COMM_WORLD);
    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &ybot, 1, MPI_DOUBLE, MPI_COMM_WORLD);
    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &nx, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &ny, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &h, 1, MPI_DOUBLE, MPI_COMM_WORLD);
    std::cout << MPI_position << " " << xleft << " " << ybot << " " << nx << " " << ny << " " << h << std::endl;

    cartesianGrid = Numeric::CartesianGridOfSpeed({nx,ny}, point{xleft,ybot}, h);

    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &modeGeneration, 1, MPI_INT, MPI_COMM_WORLD);

      std::cout << MPI_position << " " << modeGeneration << std::endl;
    if (modeGeneration == 0) // Génération sur toute la grille 
    {
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &nbPoints, 1, MPI_INT, MPI_COMM_WORLD);
      std::cout << MPI_position << " " << nbPoints << std::endl;

        cloudOfPoints = Geometry::generatePointsIn(nbPoints, {cartesianGrid.getLeftBottomVertex(), cartesianGrid.getRightTopVertex()});
    }
    else 
    {
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &xl, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &xr, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &yb, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &yt, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &nbPoints, 1, MPI_INT, MPI_COMM_WORLD);

    std::cout << xl << " " << xr << " " << yb << " " << yt << " " << nbPoints << std::endl;
        cloudOfPoints = Geometry::generatePointsIn(nbPoints, {point{xl,yb}, point{xr,yt}});
    }

    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &nbVortices, 1, MPI_INT, MPI_COMM_WORLD);
      std::cout << nbVortices << std::endl;

    Simulation::Vortices vortices(nbVortices, {cartesianGrid.getLeftBottomVertex(),
                                               cartesianGrid.getRightTopVertex()});
    for (std::size_t iVortex=0; iVortex<nbVortices; ++iVortex)
    {
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &x, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &y, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &force, 1, MPI_DOUBLE, MPI_COMM_WORLD);
	std::cout << x << " " << y << " " << force << std::endl;

        vortices.setVortex(iVortex, point{x,y}, force);
    }

    MPI_Unpack(MPI_buffer, buf_size, &MPI_position, &isMobile, 1, MPI_INT, MPI_COMM_WORLD);
      std::cout << isMobile << std::endl;

    return std::make_tuple(vortices, isMobile, cartesianGrid, cloudOfPoints);
}

int main( int nargs, char* argv[] )
{
  int rank; // rang du processus
  int nprocs; // nombre de processus en tout
  MPI_Status status;

  MPI_Init(&nargs, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

  if (rank == 0) {
    // Processus realisant l'IHM

    // Analyse de la ligne de commande
    if (nargs==1) {
      std::cerr << "Usage : vortexsimulator <nom fichier configuration>" << std::endl;
      return EXIT_FAILURE;
    }
    std::ifstream fich(argv[1]);
    if (fich.fail()) {
      std::cerr << "Erreur lors de la lecture du fichier \"" << argv[1] << "\"" << std::endl;
      return EXIT_FAILURE;
    }
    auto config = readConfigFile(fich);
    fich.close();

    std::size_t resx=800, resy=600;
    if (nargs > 3) {
      resx = std::stoull(argv[2]);
      resy = std::stoull(argv[3]);
    }

    // Transmission de la configuration aux processus de calcul
    std::cout << "taille envoyee = " << MPI_position << std::endl;
    MPI_Send(MPI_buffer, MPI_position, MPI_PACKED, 1, 0, MPI_COMM_WORLD);
    //MPI_Bcast(MPI_buffer, MPI_position, MPI_PACKED, 0, MPI_COMM_WORLD);
 
    // Affichage de la configuration
    auto vortices = std::get<0>(config);
    auto isMobile = std::get<1>(config);
    auto grid     = std::get<2>(config);
    auto cloud    = std::get<3>(config);

    std::cout << "######## Vortex simultor ########" << std::endl << std::endl;
    std::cout << "Press P for play animation " << std::endl;
    std::cout << "Press S to stop animation" << std::endl;
    std::cout << "Press right cursor to advance step by step in time" << std::endl;
    std::cout << "Press down cursor to halve the time step" << std::endl;
    std::cout << "Press up cursor to double the time step" << std::endl;

    // On recupere la grille initiale
    MPI_Recv(grid.data(), grid.cellGeometry().first*grid.cellGeometry().second, MPI_DOUBLE, 1, 1, MPI_COMM_WORLD, &status);

    std::cout << "affichage" << std::endl;
    // Creation de l'image
    Graphisme::Screen myScreen( {resx,resy}, {grid.getLeftBottomVertex(), grid.getRightTopVertex()} );
    bool animate=false;
    double dt = 0.1;

    // Boucle evenementielle
    while (myScreen.isOpen())
    {
        auto start = std::chrono::system_clock::now();
        bool advance = false;
        // on inspecte tous les évènements de la fenêtre qui ont été émis depuis la précédente itération
        sf::Event event;
        while (myScreen.pollEvent(event))
        {
            // évènement "fermeture demandée" : on ferme la fenêtre
            if (event.type == sf::Event::Closed)
                myScreen.close();
            if (event.type == sf::Event::Resized)
            {
                // on met à jour la vue, avec la nouvelle taille de la fenêtre
                myScreen.resize(event);
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::P)) animate = true;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) animate = false;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) dt *= 2;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) dt /= 2;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) advance = true;
        }
        if (animate | advance)
        {
            if (isMobile)
            {
                cloud = Numeric::solve_RK4_movable_vortices(dt, grid, vortices, cloud);
            }
            else
            {
                cloud = Numeric::solve_RK4_fixed_vortices(dt, grid, cloud);
            }
        }
        myScreen.clear(sf::Color::Black);
        std::string strDt = std::string("Time step : ") + std::to_string(dt);
        myScreen.drawText(strDt, Geometry::Point<double>{50, double(myScreen.getGeometry().second-96)});
        myScreen.displayVelocityField(grid, vortices);
        myScreen.displayParticles(grid, vortices, cloud);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = end - start;
        std::string str_fps = std::string("FPS : ") + std::to_string(1./diff.count());
        myScreen.drawText(str_fps, Geometry::Point<double>{300, double(myScreen.getGeometry().second-96)});
        myScreen.display();   
    }
  } else {
    // Processus effectuant les calculs

        std::cout << "calcul" << std::endl;

    // Reception de la configuration
    int buf_size;
    MPI_Probe(0, 0,  MPI_COMM_WORLD, &status);
    MPI_Get_count(&status, MPI_PACKED, &buf_size);
    std::cout << "taille recue = " << buf_size << std::endl;
    
    assert((MPI_buffer = (char *)malloc(buf_size)) != NULL);
    MPI_Recv(MPI_buffer, buf_size, MPI_PACKED, 0, 0, MPI_COMM_WORLD, &status);
        std::cout << "calcul" << std::endl;

    // Instantiation des differentes classes
    auto config = initComputing(buf_size);
        std::cout << "calcul" << std::endl;

    auto vortices = std::get<0>(config);
    auto isMobile = std::get<1>(config);
    auto grid     = std::get<2>(config);
    auto cloud    = std::get<3>(config);

    // Premier calcul de l'image
    grid.updateVelocityField(vortices);

    // On envoie le resultat pour affichage
    MPI_Send(grid.data(), grid.cellGeometry().first*grid.cellGeometry().second, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
        std::cout << "envoye le calcul" << std::endl;
    MPI_Probe(0, 0,  MPI_COMM_WORLD, &status);
        std::cout << "envoye le calcul" << std::endl;
  }
  return EXIT_SUCCESS;
 }
